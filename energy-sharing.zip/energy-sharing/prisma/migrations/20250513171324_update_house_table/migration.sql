-- AlterTable
ALTER TABLE "House" ADD COLUMN     "description" TEXT;
