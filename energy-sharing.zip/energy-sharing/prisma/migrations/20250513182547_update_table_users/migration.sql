/*
  Warnings:

  - You are about to drop the column `admim` on the `users` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "users" DROP COLUMN "admim",
ADD COLUMN     "admin" BOOLEAN NOT NULL DEFAULT false;
