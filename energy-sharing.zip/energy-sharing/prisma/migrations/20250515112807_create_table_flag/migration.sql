/*
  Warnings:

  - Added the required column `additional_value` to the `flags` table without a default value. This is not possible if the table is not empty.
  - Added the required column `consumptionReference` to the `flags` table without a default value. This is not possible if the table is not empty.
  - Added the required column `name` to the `flags` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "flags" ADD COLUMN     "active" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "additional_value" DOUBLE PRECISION NOT NULL,
ADD COLUMN     "consumptionReference" DOUBLE PRECISION NOT NULL,
ADD COLUMN     "name" TEXT NOT NULL;
