/*
  Warnings:

  - You are about to drop the column `consumptionReference` on the `flags` table. All the data in the column will be lost.
  - Added the required column `consumption_reference` to the `flags` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "flags" DROP COLUMN "consumptionReference",
ADD COLUMN     "consumption_reference" DOUBLE PRECISION NOT NULL;
