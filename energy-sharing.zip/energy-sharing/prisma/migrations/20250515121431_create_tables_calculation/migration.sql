-- CreateTable
CREATE TABLE "energy_calculations" (
    "id" SERIAL NOT NULL,
    "houseId" INTEGER NOT NULL,
    "flagId" INTEGER NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "consumption" DOUBLE PRECISION NOT NULL,
    "value" DOUBLE PRECISION,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "energy_calculations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "energy_calculation_rates" (
    "id" SERIAL NOT NULL,
    "energyCalculationId" INTEGER NOT NULL,
    "rateId" INTEGER NOT NULL,
    "value" DOUBLE PRECISION NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "energy_calculation_rates_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "energy_calculation_flag" (
    "id" SERIAL NOT NULL,
    "energyCalculationId" INTEGER NOT NULL,
    "flagId" INTEGER NOT NULL,
    "value" DOUBLE PRECISION NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "energy_calculation_flag_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "energy_calculations" ADD CONSTRAINT "energy_calculations_houseId_fkey" FOREIGN KEY ("houseId") REFERENCES "houses"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "energy_calculations" ADD CONSTRAINT "energy_calculations_flagId_fkey" FOREIGN KEY ("flagId") REFERENCES "flags"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "energy_calculation_rates" ADD CONSTRAINT "energy_calculation_rates_energyCalculationId_fkey" FOREIGN KEY ("energyCalculationId") REFERENCES "energy_calculations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "energy_calculation_rates" ADD CONSTRAINT "energy_calculation_rates_rateId_fkey" FOREIGN KEY ("rateId") REFERENCES "rates"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "energy_calculation_flag" ADD CONSTRAINT "energy_calculation_flag_energyCalculationId_fkey" FOREIGN KEY ("energyCalculationId") REFERENCES "energy_calculations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "energy_calculation_flag" ADD CONSTRAINT "energy_calculation_flag_flagId_fkey" FOREIGN KEY ("flagId") REFERENCES "flags"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
