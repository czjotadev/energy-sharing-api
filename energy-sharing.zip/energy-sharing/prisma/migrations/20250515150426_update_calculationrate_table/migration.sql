-- AlterTable
ALTER TABLE "energy_calculation_rates" ADD COLUMN     "description" TEXT;
