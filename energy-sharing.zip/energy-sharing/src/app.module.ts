import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { PrismaService } from './configurations/prisma/prisma.service';
import { RatesModule } from './modules/rates/rates.module';
import { UsersModule } from './modules/users/users.module';
import { HousesModule } from './modules/houses/houses.module';
import { TenantsModule } from './modules/tenants/tenants.module';
import { FlagsModule } from './modules/flags/flags.module';
import { EnergyCalculationsModule } from './modules/energy-calculations/energy-calculations.module';

@Module({
  imports: [RatesModule, UsersModule, HousesModule, TenantsModule, FlagsModule, EnergyCalculationsModule],
  controllers: [AppController],
  providers: [AppService, PrismaService],
})
export class AppModule {}
