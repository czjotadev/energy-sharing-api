import { IsDate, IsDateString, IsNumber } from "class-validator";

export class CreateEnergyCalculationDto {

    @IsNumber({}, { message: 'O campo casa é obrigatório.' })
    houseId: number;

    @IsNumber({}, { message: 'O campo bandeira é obrigatório.' })
    flagId: number;

    @IsDateString({}, { message: 'O campo data é obrigatório.' })
    date: Date;

    @IsNumber({}, { message: 'O campo consumo é obrigatório.' })
    consumption: number;
}
