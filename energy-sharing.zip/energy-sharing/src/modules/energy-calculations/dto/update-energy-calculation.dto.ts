import { PartialType } from '@nestjs/swagger';
import { CreateEnergyCalculationDto } from './create-energy-calculation.dto';

export class UpdateEnergyCalculationDto extends PartialType(CreateEnergyCalculationDto) {}
