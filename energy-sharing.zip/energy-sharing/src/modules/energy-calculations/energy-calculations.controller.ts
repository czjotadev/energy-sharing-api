import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { EnergyCalculationsService } from './energy-calculations.service';
import { CreateEnergyCalculationDto } from './dto/create-energy-calculation.dto';
import { UpdateEnergyCalculationDto } from './dto/update-energy-calculation.dto';

@Controller('energy-calculations')
export class EnergyCalculationsController {
  constructor(private readonly energyCalculationsService: EnergyCalculationsService) {}

  @Post()
  create(@Body() createEnergyCalculationDto: CreateEnergyCalculationDto) {
    return this.energyCalculationsService.create(createEnergyCalculationDto);
  }

  @Get()
  findAll() {
    return this.energyCalculationsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.energyCalculationsService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateEnergyCalculationDto: UpdateEnergyCalculationDto) {
    return this.energyCalculationsService.update(+id, updateEnergyCalculationDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.energyCalculationsService.remove(+id);
  }
}
