import { Module } from '@nestjs/common';
import { EnergyCalculationsService } from './energy-calculations.service';
import { EnergyCalculationsController } from './energy-calculations.controller';
import { PrismaService } from 'src/configurations/prisma/prisma.service';

@Module({
  controllers: [EnergyCalculationsController],
  providers: [EnergyCalculationsService, PrismaService],
})
export class EnergyCalculationsModule {}
