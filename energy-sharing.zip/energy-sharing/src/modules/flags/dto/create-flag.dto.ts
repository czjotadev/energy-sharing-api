import { IsBoolean, IsNumber, IsString, Min, MinLength } from "class-validator";

export class CreateFlagDto {

    @IsString({ message: 'O nome da bandeira deve ser informado.' })
    @MinLength(3, { message: 'O nome da bandeira deve ter no mínimo 3 caracteres.' })
    name: string

    @IsNumber({}, { message: 'O valor de referencia deve ser informado.' })
    @Min(0, { message: 'O valor de referencia não pode ser menor que zero.' })
    consumptionReference: number

    @IsNumber({}, { message: 'O valor adicional deve ser informado.' })
    @Min(0, { message: 'O valor adicional não pode ser menor que zero.' })
    additionalValue: number

    @IsBoolean({ message: 'O status da bandeira deve ser informado.' })
    active: boolean

}
