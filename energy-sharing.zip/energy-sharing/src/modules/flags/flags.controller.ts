import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { FlagsService } from './flags.service';
import { CreateFlagDto } from './dto/create-flag.dto';
import { UpdateFlagDto } from './dto/update-flag.dto';
import { FlagInterface } from './interfaces/flag.interface';

@Controller('flags')
export class FlagsController {
  constructor(private readonly flagsService: FlagsService) { }

  @Post()
  create(@Body() createFlagDto: CreateFlagDto): Promise<{ message: string, data: FlagInterface }> {
    return this.flagsService.create(createFlagDto);
  }

  @Get()
  findAll(): Promise<FlagInterface[]> {
    return this.flagsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string): Promise<FlagInterface> {
    return this.flagsService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateFlagDto: UpdateFlagDto): Promise<{ message: string, data: FlagInterface }> {
    return this.flagsService.update(+id, updateFlagDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string): Promise<{ message: string }> {
    return this.flagsService.remove(+id);
  }
}
