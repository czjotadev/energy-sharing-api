import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateFlagDto } from './dto/create-flag.dto';
import { UpdateFlagDto } from './dto/update-flag.dto';
import { FlagInterface } from './interfaces/flag.interface';
import { PrismaService } from 'src/configurations/prisma/prisma.service';

@Injectable()
export class FlagsService {

  constructor(private prismaService: PrismaService) { }

  async create(createFlagDto: CreateFlagDto): Promise<{ message: string, data: FlagInterface }> {
    try {
      const { active, additionalValue, name, consumptionReference } = createFlagDto;

      const flag: FlagInterface = await this.prismaService.flag.create({
        data: {
          name,
          consumptionReference,
          additionalValue,
          active
        }
      })

      return { message: 'Cadastro realizado com sucesso.', data: flag }

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao realizar cadastro`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async findAll(): Promise<FlagInterface[]> {
    try {
      const flags = await this.prismaService.flag.findMany({
        where: {
          deletedAt: null
        }
      })

      return flags;
    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao listar registros.`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async findOne(id: number): Promise<FlagInterface> {
    try {
      const flag = await this.prismaService.flag.findFirstOrThrow({
        where: {
          id,
          deletedAt: null
        }
      })

      return flag;
    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao listar registros.`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async update(id: number, updateFlagDto: UpdateFlagDto): Promise<{ message: string, data: FlagInterface }> {
    try {

      const { name, consumptionReference, additionalValue, active } = updateFlagDto;

      await this.findOne(id)

      const updatedFlag = await this.prismaService.flag.update({
        where: {
          id,
        },
        data: {
          name,
          consumptionReference,
          additionalValue,
          active
        }
      })

      return { message: 'Registro atualizado com sucesso.', data: updatedFlag }

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao listar registros.`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async remove(id: number): Promise<{ message: string }> {
    try {
      await this.findOne(id)

      await this.prismaService.flag.update({
        where: {
          id
        },
        data: {
          deletedAt: new Date()
        }
      })

      return { message: 'Registro excluído com sucesso.' }
    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao listar registros.`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }
}
