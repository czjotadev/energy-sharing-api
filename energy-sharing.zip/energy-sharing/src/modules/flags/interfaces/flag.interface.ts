export class FlagInterface {
    id: number;
    name: string;
    consumptionReference: number;
    additionalValue: number;
    active: boolean;
}