import { IsOptional, IsString, MaxLength } from "class-validator";

export class CreateHouseDto {

    @IsString({ message: 'Informe o número da casa.' })
    @MaxLength(10, { message: 'O número da casa não pode conter mais de 10 caracteres.' })
    number: string;

    @IsString()
    @IsOptional()
    @MaxLength(255, { message: 'A descição da casa não pode ser maior que 255 caracteres.'})
    description: string;
}
