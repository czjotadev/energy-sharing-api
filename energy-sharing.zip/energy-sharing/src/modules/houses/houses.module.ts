import { Module } from '@nestjs/common';
import { HousesService } from './houses.service';
import { HousesController } from './houses.controller';
import { PrismaService } from 'src/configurations/prisma/prisma.service';

@Module({
  controllers: [HousesController],
  providers: [HousesService, PrismaService],
})
export class HousesModule {}
