import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateHouseDto } from './dto/create-house.dto';
import { UpdateHouseDto } from './dto/update-house.dto';
import { PrismaService } from 'src/configurations/prisma/prisma.service';
import { HouseInterface } from './interfaces/house.interface';

@Injectable()
export class HousesService {

  constructor(private prismaService: PrismaService) { }

  async create(createHouseDto: CreateHouseDto): Promise<{ message: string, data: HouseInterface }> {
    try {
      const { number, description } = createHouseDto;

      const exists = await this.prismaService.house.findFirst({
        where: {
          number,
          deletedAt: null
        }
      })

      if (exists) {
        throw new HttpException(`Não foi possível realizar o registro. Já existe uma casa com o número ${exists.number}`, HttpStatus.BAD_REQUEST)
      }

      const result = await this.prismaService.house.create({
        data: {
          number,
          description
        }
      })

      return {
        message: 'Cadastro realizado com sucesso',
        data: result
      }

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao realizar cadastro`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async findAll(): Promise<HouseInterface[]> {
    try {

      const result = await this.prismaService.house.findMany({
        where: {
          deletedAt: null
        }
      });

      return result;

    } catch (error) {
      throw new HttpException(`Erro ao consultar os dados`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async findOne(id: number): Promise<HouseInterface> {
    try {
      const house = await this.prismaService.house.findFirst({
        where: {
          id,
          deletedAt: null
        }
      })

      if (!house) {
        throw new HttpException(`Não foi possível localizar o registro.`, HttpStatus.BAD_REQUEST)
      }

      return house

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao editar registro`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async update(id: number, updateHouseDto: UpdateHouseDto): Promise<{ message: string, data: HouseInterface }> {
    try {

      const house = await this.prismaService.house.findFirst({
        where: {
          id,
          deletedAt: null
        }
      })

      if (!house) {
        throw new HttpException(`Não foi possível localizar o registro.`, HttpStatus.BAD_REQUEST)
      }

      const { number, description } = updateHouseDto;

      const updatedHouse = await this.prismaService.house.update({
        where: {
          id
        },
        data: {
          number,
          description
        }
      })

      return {
        message: 'Registro atualizado com sucesso.',
        data: updatedHouse
      }

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao editar registro`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async remove(id: number) {
    try {

      const house = await this.prismaService.house.findFirst({
        where: {
          id,
          deletedAt: null
        }
      })

      if (!house) {
        throw new HttpException(`Não foi possível localizar o registro.`, HttpStatus.BAD_REQUEST)
      }

      await this.prismaService.house.update({
        where: {
          id
        },
        data: {
          deletedAt: new Date()
        }
      })

      return { message: 'Registro removido com sucesso.'}

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao remover registro.`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }
}
