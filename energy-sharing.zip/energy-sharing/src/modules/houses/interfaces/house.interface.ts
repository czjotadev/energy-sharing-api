export interface HouseInterface {
    id: number;
    number: string;
    description: string | null;
    createdAt: Date;
    updatedAt: Date;
    deletedAt: Date | null;
}