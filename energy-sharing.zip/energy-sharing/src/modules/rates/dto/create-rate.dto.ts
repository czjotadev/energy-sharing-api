import { IsBoolean, IsEnum, IsNumber, IsString, MaxLength, Min } from "class-validator";
import { RateType } from "../enum/rate-type.enum";

export class CreateRateDto {

    @IsString()
    @MaxLength(100, { message: 'O tamanho máximo do nome do imposto deve ser de 100 caracteres.' })
    name: string;

    @IsEnum(RateType, { message: 'O tipo da taxa deve ser Fixo ou Consumo.' })
    type: RateType;

    @IsNumber({}, { message: 'O valor da taxa deve ser informado.' })
    @Min(0.1, { message: 'O valor mínimo da taxa deve ser 0.1' })
    value: number;

    @IsBoolean()
    active: boolean
}
