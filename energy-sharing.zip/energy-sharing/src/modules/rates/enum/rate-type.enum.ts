export enum RateType {
  FIXED = 'FIXED',
  CONSUMPTION = 'CONSUMPTION',
  TAXATION = 'TAXATION'
}