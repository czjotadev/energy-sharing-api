import { RateType  } from "generated/prisma";

export interface RateInterface {
    id: number;
    name: string;
    type: RateType;
    value: number;
    active: boolean;
}