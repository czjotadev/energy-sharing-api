import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateRateDto } from './dto/create-rate.dto';
import { UpdateRateDto } from './dto/update-rate.dto';
import { PrismaService } from 'src/configurations/prisma/prisma.service';

@Injectable()
export class RatesService {

  constructor(private prismaService: PrismaService) { }

  async create(createRateDto: CreateRateDto) {
    try {
      const { name, type, active, value } = createRateDto;

      const exists = await this.prismaService.rate.findFirst({
        where: {
          name,
          deletedAt: null
        }
      })

      if (exists) {
        throw new HttpException(`Não foi possível realizar o registro. Já existe uma taxa com o número ${exists.name}`, HttpStatus.BAD_REQUEST)
      }

      const result = await this.prismaService.rate.create({
        data: {
          name,
          type,
          active,
          value
        }
      })

      return {
        message: 'Cadastro realizado com sucesso',
        data: result
      }

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao realizar cadastro`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async findAll() {
    try {

      const result = await this.prismaService.rate.findMany({
        where: {
          deletedAt: null
        }
      });

      return result;

    } catch (error) {
      throw new HttpException(`Erro ao consultar os dados.`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async findOne(id: number) {
    try {
      const rate = await this.prismaService.rate.findFirst({
        where: {
          id,
          deletedAt: null
        }
      })

      if (!rate) {
        throw new HttpException(`Não foi possível localizar o registro.`, HttpStatus.BAD_REQUEST)
      }

      return rate

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao editar registro`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async update(id: number, updateRateDto: UpdateRateDto) {
    try {

      const rate = await this.prismaService.rate.findFirst({
        where: {
          id,
          deletedAt: null
        }
      })

      if (!rate) {
        throw new HttpException(`Não foi possível localizar o registro.`, HttpStatus.BAD_REQUEST)
      }

      const { name, type, active, value } = updateRateDto;

      const updatedRate = await this.prismaService.rate.update({
        where: {
          id
        },
        data: {
          name,
          type,
          active,
          value
        }
      })

      return {
        message: 'Registro atualizado com sucesso.',
        data: updatedRate
      }

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao editar registro`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async remove(id: number) {
    try {

      const rate = await this.prismaService.rate.findFirst({
        where: {
          id,
          deletedAt: null
        }
      })

      if (!rate) {
        throw new HttpException(`Não foi possível localizar o registro.`, HttpStatus.BAD_REQUEST)
      }

      await this.prismaService.rate.update({
        where: {
          id
        },
        data: {
          deletedAt: new Date()
        }
      })

      return { message: 'Registro removido com sucesso.' }

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao remover registro.`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }
}
