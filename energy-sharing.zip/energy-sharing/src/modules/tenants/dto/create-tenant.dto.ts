import { IsArray, IsNumber, IsOptional } from "class-validator";

export class CreateTenantDto {

    @IsNumber({}, { message: 'O id do usuário deve ser um número.' })
    userId: number;

    @IsArray()
    @IsOptional()
    houseIds: number[];
}
