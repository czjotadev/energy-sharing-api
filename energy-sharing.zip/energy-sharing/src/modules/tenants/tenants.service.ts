import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateTenantDto } from './dto/create-tenant.dto';
import { UpdateTenantDto } from './dto/update-tenant.dto';
import { PrismaService } from 'src/configurations/prisma/prisma.service';

@Injectable()
export class TenantsService {

  constructor(private prismaService: PrismaService) { }

  async create(createTenantDto: CreateTenantDto) {
    try {
      const { userId, houseIds } = createTenantDto;

      const data = houseIds.map((houseId) => {
        return {
          userId,
          houseId
        }
      })

      const result = await this.prismaService.tenant.createMany({ data })

      return {
        message: 'Cadastro realizado com sucesso',
        data: result
      }

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao realizar cadastro`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async findAll() {
    try {

      const result = await this.prismaService.tenant.findMany({
        where: {
          deletedAt: null
        }
      });

      return result;

    } catch (error) {
      throw new HttpException(`Erro ao consultar os dados.`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async findOne(id: number) {
    try {
      const tenant = await this.prismaService.tenant.findFirst({
        where: {
          id,
          deletedAt: null
        }
      })

      if (!tenant) {
        throw new HttpException(`Não foi possível localizar o registro.`, HttpStatus.BAD_REQUEST)
      }

      return tenant

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao editar registro`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async update(id: number, updateTenantDto: UpdateTenantDto) {
    try {

      const tenant = await this.prismaService.tenant.findFirst({
        where: {
          id,
          deletedAt: null
        }
      })

      if (!tenant) {
        throw new HttpException(`Não foi possível localizar o registro.`, HttpStatus.BAD_REQUEST)
      }

      const { userId, houseIds } = updateTenantDto;

      const updateTenant = await this.prismaService.tenant.update({
        where: {
          id
        },
        data: {
          userId,
          houseId: houseIds ? houseIds[0] : undefined
        }
      })

      return {
        message: 'Registro atualizado com sucesso.',
        data: updateTenant
      }

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao editar registro`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  async remove(id: number) {
    try {

      const tenant = await this.prismaService.tenant.findFirst({
        where: {
          id,
          deletedAt: null
        }
      })

      if (!tenant) {
        throw new HttpException(`Não foi possível localizar o registro.`, HttpStatus.BAD_REQUEST)
      }

      await this.prismaService.tenant.update({
        where: {
          id
        },
        data: {
          deletedAt: new Date()
        }
      })

      return { message: 'Registro removido com sucesso.' }

    } catch (error) {
      if (error instanceof HttpException) {
        throw new HttpException(error.message, error.getStatus())
      }
      throw new HttpException(`Erro ao remover registro.`, HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }
}
