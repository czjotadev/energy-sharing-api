import { IsBoolean, IsOptional, IsString, IsStrongPassword, Matches, MaxLength, MinLength } from "class-validator";

export class CreateUserDto {

    @MinLength(5, { message: 'O Nome de Usuário deve possuir no mínimo 5 caracteres.' })
    @MaxLength(20, { message: 'O Nome de Usuário deve possuir no máximo 20 caracteres.' })
    @Matches(/^[a-zA-Z0-9_-]+$/, {
        message: 'Username deve conter apenas letras, números, underline (_) ou hífen (-), sem espaços.',
    })
    @IsString({ message: 'O Nome de Usuário deve ser texto.' })
    username: string;

    @MinLength(5, { message: 'O Nome deve possuir no mínimo 5 caracteres.' })
    @MaxLength(100, { message: 'O Nome deve possuir no máximo 100 caracteres.' })
    @IsString({ message: 'O Nome deve ser texto.' })
    name: string;

    @IsString()
    @IsStrongPassword({ minLength: 8, minSymbols: 1, minNumbers: 1, minUppercase: 1 }, { message: 'O campo deve conter no mínimo 8 caracteres, sendo eles 1 letra maiúscula, 1 número e 1 simbolo.' })
    password: string;

    @IsBoolean()
    @IsOptional()
    admin: boolean = false;
}
