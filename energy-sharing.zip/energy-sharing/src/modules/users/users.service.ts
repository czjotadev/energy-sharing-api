import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { PrismaService } from 'src/configurations/prisma/prisma.service';
import { CreateUserDto } from './dto/create-user.dto';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) { }

  async create(createUserDto: CreateUserDto) {
    try {

      const { admin, name, password, username } = createUserDto

      const userExists = await this.prisma.user.findFirst({
        where: {
          username,
        },
      });

      if (userExists) {
        throw new HttpException('Usuário já existe.', HttpStatus.BAD_REQUEST);
      }

      const hashedPassword = await bcrypt.hash(password, 10);

      const user = await this.prisma.user.create({
        data: {
          name,
          username,
          password: hashedPassword,
          admin
        }
      });

      return {
        message: 'Usuário criado com sucesso.',
        data: user,
      };
    } catch (error) {
      throw new HttpException(
        error instanceof HttpException ? error.message : 'Erro ao criar usuário.',
        error instanceof HttpException ? error.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  async findAll() {
    try {
      const users = await this.prisma.user.findMany({
        where: { deletedAt: null },
      });

      return users;
    } catch {
      throw new HttpException(
        'Erro ao consultar usuários.',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  async findOne(id: number) {
    try {
      const user = await this.prisma.user.findFirst({
        where: {
          id,
          deletedAt: null,
        },
      });

      if (!user) {
        throw new HttpException('Usuário não encontrado.', HttpStatus.NOT_FOUND);
      }

      return user;
    } catch (error) {
      throw new HttpException(
        error instanceof HttpException ? error.message : 'Erro ao buscar usuário.',
        error instanceof HttpException ? error.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  async update(id: number, updateData: Partial<CreateUserDto>) {
    try {
      const user = await this.findOne(id);

      const updated = await this.prisma.user.update({
        where: { id },
        data: updateData,
      });

      return {
        message: 'Usuário atualizado com sucesso.',
        data: updated,
      };
    } catch (error) {
      throw new HttpException(
        error instanceof HttpException ? error.message : 'Erro ao atualizar usuário.',
        error instanceof HttpException ? error.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  async remove(id: number) {
    try {
      await this.findOne(id);

      await this.prisma.user.update({
        where: { id },
        data: { deletedAt: new Date() },
      });

      return { message: 'Usuário removido com sucesso.' };
    } catch (error) {
      throw new HttpException(
        error instanceof HttpException ? error.message : 'Erro ao remover usuário.',
        error instanceof HttpException ? error.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}